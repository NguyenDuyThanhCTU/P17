import AdminPage from "@components/admin/AdminPage";
import React from "react";

const page = () => {
  return (
    <div>
      <AdminPage />
    </div>
  );
};

export default page;
