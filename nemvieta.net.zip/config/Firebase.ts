import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyDPNYVK8tWN_umdcJZ-g80hBWftlFXndCU",

  authDomain: "nemvieta-b328d.firebaseapp.com",

  projectId: "nemvieta-b328d",

  storageBucket: "nemvieta-b328d.appspot.com",

  messagingSenderId: "840560038423",

  appId: "1:840560038423:web:2b0db2541e685ef1150252",

  measurementId: "G-T1MJ9FC592",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});
// export const db = getFirestore(app);

export const auth = getAuth(app);
